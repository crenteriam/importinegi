NSS: No cuenta con elementos para responder
