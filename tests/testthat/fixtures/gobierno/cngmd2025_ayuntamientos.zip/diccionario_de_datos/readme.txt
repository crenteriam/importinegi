NSS: No cuenta con elementos para responder
NA: No aplica
ND: Informacion no disponible
NP: No publicable
