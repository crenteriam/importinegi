Descripcion de las carpetas del paquete de datos abiertos.
