NSS: No cuenta con elementos para responder
NA: No aplica
ND: Información no disponible
NP: No publicable
