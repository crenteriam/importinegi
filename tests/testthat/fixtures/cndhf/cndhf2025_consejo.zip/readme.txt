Descripción de las carpetas del paquete de datos abiertos (muestra inventada)
